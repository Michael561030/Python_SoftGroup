def pal(arg):
    arg=arg.lower()
    arg=arg.replace(' ','')
    argRev=arg[::-1]
    if arg == argRev:
        print('True')
    else:
        print('False')

f=input('Please, enter something: ')
pal(f)
