import os
from os import path
def func(args):
    for top, dirs, files in os.walk(args):
      for nm in files:       
        print (os.path.join(top, nm))
f=input('Enter path: ')
func(f)
