def func(n):
    for i in range(n,-1,-1):
        print(i)
func(5)
