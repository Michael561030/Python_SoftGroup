from functools import reduce
def adder(*args):
    return reduce((lambda x,y: x+y), map(lambda x: x*x, args))
print(adder(56,22,1,5,6))
